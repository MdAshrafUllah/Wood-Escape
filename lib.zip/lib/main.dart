import 'package:ant_go/core/router/router.dart';
import 'package:ant_go/core/theme/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Force portrait mode
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const ProviderScope(child: UnblockMeApp()));
}

class UnblockMeApp extends StatelessWidget {
  const UnblockMeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Unblock Me',
      theme: AppTheme.darkTheme,
      routerConfig: appRouter,
    );
  }
}
