abstract class PageRoutes {
  static const String home = '/${AppRoutes.home}';
  static const String levels = '/${AppRoutes.levels}';
  static const String game = '/${AppRoutes.game}';
}

abstract class AppRoutes {
  static const String home = 'home';
  static const String levels = 'levels';
  static const String game = 'game';
}
