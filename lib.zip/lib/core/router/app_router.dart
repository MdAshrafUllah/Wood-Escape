import 'package:ant_go/core/router/routers.dart';
import 'package:ant_go/presentation/screens/game_screen.dart';
import 'package:ant_go/presentation/screens/home_screen/home_screen.dart';
import 'package:ant_go/presentation/screens/level_select_screen/level_select_screen.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

final GoRouter appRouter = GoRouter(
  initialLocation: PageRoutes.home,
  routes: [
    GoRoute(
      name: AppRoutes.home,
      path: PageRoutes.home,
      pageBuilder: (context, state) => _buildPageTransition(const HomeScreen()),
    ),
    GoRoute(
      name: AppRoutes.levels,
      path: PageRoutes.levels,
      pageBuilder: (context, state) =>
          _buildPageTransition(const LevelSelectScreen()),
    ),
    GoRoute(
      name: AppRoutes.game,
      path: PageRoutes.game,
      pageBuilder: (context, state) => _buildPageTransition(const GameScreen()),
    ),
  ],
);

Page _buildPageTransition(Widget child) {
  return CustomTransitionPage(
    child: child,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      return FadeTransition(
        opacity: CurveTween(curve: Curves.easeInOut).animate(animation),
        child: child,
      );
    },
  );
}
