import 'package:ant_go/presentation/game_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/engine/game_board.dart';

// 1. StatefulWidget ke ConsumerStatefulWidget korun
class GameBoardWidget extends ConsumerStatefulWidget {
  final GameBoard board;
  final Function() onMove;
  final Function() onWin;

  const GameBoardWidget({
    super.key,
    required this.board,
    required this.onMove,
    required this.onWin,
  });

  @override
  ConsumerState<GameBoardWidget> createState() => _GameBoardWidgetState();
}

// 2. State ke ConsumerState ekhaney convert korun
class _GameBoardWidgetState extends ConsumerState<GameBoardWidget> {
  double dragAccumulator = 0.0;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        double tileSize = constraints.maxWidth / widget.board.gridSize;

        return Container(
          width: constraints.maxWidth,
          height: constraints.maxWidth,
          decoration: BoxDecoration(
            color: const Color(0xFF3E2723), // Dark wood frame
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF5D4037), width: 8),
          ),
          child: Stack(
            children: [
              // 1. Draw Grid Background
              Positioned.fill(
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: widget.board.gridSize,
                  ),
                  itemCount: 36,
                  itemBuilder: (context, index) {
                    return Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.brown.shade700.withOpacity(0.3),
                        ),
                        color: const Color(0xFF4E342E),
                      ),
                    );
                  },
                ),
              ),

              // 2. Render Interactive Blocks
              ...widget.board.blocks.map((block) {
                double left = block.col * tileSize;
                double top = block.row * tileSize;
                double width = block.isHorizontal
                    ? block.length * tileSize
                    : tileSize;
                double height = block.isHorizontal
                    ? tileSize
                    : block.length * tileSize;

                return Positioned(
                  left: left,
                  top: top,
                  width: width,
                  height: height,
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onPanStart: (_) => dragAccumulator = 0.0,
                    onPanUpdate: (details) {
                      double delta = block.isHorizontal
                          ? details.delta.dx
                          : details.delta.dy;
                      dragAccumulator += delta;

                      if (dragAccumulator.abs() >= tileSize * 0.5) {
                        int step = dragAccumulator > 0 ? 1 : -1;
                        int deltaRow = block.isHorizontal ? 0 : step;
                        int deltaCol = block.isHorizontal ? step : 0;

                        // ref akhon available
                        ref
                            .read(gameProvider.notifier)
                            .moveBlock(block, deltaRow, deltaCol);

                        dragAccumulator = 0.0;
                        widget.onMove();
                        setState(() {});

                        if (ref.read(gameProvider).board.isWinConditionMet()) {
                          widget.onWin();
                        }
                      }
                    },
                    child: Container(
                      margin: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: block.isTarget
                            ? Colors.redAccent
                            : Colors.orange.shade700,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: const [
                          BoxShadow(
                            color: Colors.black38,
                            blurRadius: 4,
                            offset: Offset(2, 2),
                          ),
                        ],
                        border: Border.all(color: Colors.white24, width: 2),
                      ),
                      child: Center(
                        child: Text(
                          block.id,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ],
          ),
        );
      },
    );
  }
}
